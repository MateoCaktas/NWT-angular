import { Component, OnInit, Input } from '@angular/core';
import { IProduct } from './product';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from './product.service';

@Component({
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
  pageTitle: string = "Product Detail";
  product: IProduct;
  errorMessage = '';
  Prosjek: number;
  Sum: number = 0;
  myFavorites: IProduct[];
  @Input() favoriteProducts: IProduct[];

  products: IProduct[] = [];

  constructor(private route: ActivatedRoute,
              private router: Router,
              private productService : ProductService) { } 
  

  calculateSum(): void{
    this.product.ratings.forEach(element => {
    this.Sum = this.Sum + element;
    });
    this.Prosjek = this.Sum / this.product.ratings.length;
    console.log(this.Sum);
    console.log(this.Prosjek);
  }
  

  ngOnInit() {
     const param = this.route.snapshot.paramMap.get('id');
    if (param) {
      const id = +param;
      this.getProduct(id);
    }

    this.Prosjek = this.Sum / this.product.ratings.length;

    console.log("Unutar detail komponente");
    console.log(this.Sum);
    console.log(this.Prosjek);
  }

  
  getProduct(id: number) {
    this.productService.getProduct(id).subscribe(
      product => this.product = product,
      error => this.errorMessage = <any>error);
  }

  onBack(): void {
    this.router.navigate(['/products']);
  }
}
