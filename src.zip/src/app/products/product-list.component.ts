import { Component, OnInit, OnChanges } from "@angular/core";
import { IProduct } from "./product";
import { ProductService } from "./product.service";

@Component({
    templateUrl: "./product-list.component.html",
    styleUrls: ["./product-list.component.css"]
})

export class ProductListComponent implements OnInit, OnChanges {
    pageTitle: string = "Product List";
    imageWidth: number = 50;
    imageMargin: number= 2;
    showImage: boolean = true;
    newVariable: string;
    _listFilter: string;
    errorMessage: string;
    isFavorite: boolean;
    myFavorites: IProduct[];

    constructor(private productService: ProductService){
        
        this.listFilter = '';
    }

    get listFilter(): string {
        return this._listFilter;
    }
    set listFilter(value: string){
        this._listFilter = value;
        this.filteredProducts= this.listFilter ? this.performFilter(this.listFilter) : this.products;
    }

    performFilter(filterBy: string): IProduct[] {
        filterBy = filterBy.toLocaleLowerCase();
        return this.products.filter((product: IProduct) => (
             product.productName.toLocaleLowerCase().indexOf(filterBy) !== -1) || 
             product.description.toLocaleLowerCase().indexOf(filterBy) !== -1);
    }

    filteredProducts: IProduct[];

    products: IProduct[] = [];


    toggleImage():void{
        this.showImage = !this.showImage;
    }

    ngOnInit(): void{
       this.productService.getProducts().subscribe(
           products => {
                this.products = products;        
                this.filteredProducts = this.products;
            },
           error => this.errorMessage = <any>error
       );

       
    }

    onRatingClicked(message: string): void{
        this.newVariable = message;
    }

    onFavoriteClicked(favorite: IProduct): void{
        console.log(`Product clicked is ${favorite}`)
        console.log("Inside onfavoriteclicked - productlist");
        this.myFavorites = this.products.filter(element => 
                element.isFavorite === true)
            };
    

    ngOnChanges():void{
        this.productService.getProducts().subscribe(
            products => {
                 this.products = products;        
                 this.filteredProducts = this.products;
             },
            error => this.errorMessage = <any>error

        );

        console.log("inside onchange");
    }
    
    buttonClick():void{
        this.products.forEach(element => {
            console.log(element);
        });
        this.myFavorites.forEach(element => {
            console.log(element);
        });
    }
}